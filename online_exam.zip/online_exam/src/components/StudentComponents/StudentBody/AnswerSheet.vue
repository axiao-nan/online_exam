<template>
    <div class="content-field">
      <div v-if="$store.state.isExamBegin" class="card">
        <div class="card-body">
          <div class="card question" v-for="question in $store.state.questionList" :key="question.id">
            <div class="card-body">
              <div class="question-content">{{ question.numId }}.{{ question.content }}</div>
              <div class="option" @click="get_ans(question.id, 'A', question.numId)" :class="{ 'selected-option': isSelected(question.id, 'A') }">A:{{ question.answerA }}</div>
              <div class="option" @click="get_ans(question.id, 'B', question.numId)" :class="{ 'selected-option': isSelected(question.id, 'B') }">B:{{ question.answerB }}</div>
              <div class="option" @click="get_ans(question.id, 'C', question.numId)" :class="{ 'selected-option': isSelected(question.id, 'C') }">C:{{ question.answerC }}</div>
              <div class="option" @click="get_ans(question.id, 'D', question.numId)" :class="{ 'selected-option': isSelected(question.id, 'D') }">D:{{ question.answerD }}</div>
            </div>
          </div>
        </div>
      </div>


      <div v-if="!$store.state.isExamBegin" class="card">
        <div class="card-body sheet-field">

          <div class="sheet-detail border-base" 
          v-for="sheet in $store.state.SubjectSheetList" :key="sheet.id"
          @click="update_paperId(sheet.id)">
            <div class="sheet-detail-info">试卷名:{{ sheet.name }}</div>
            <div class="sheet-detail-info">命题人:{{ sheet.createUser }}</div>
            <div class="sheet-detail-info">考试时间:{{ sheet.paperTime }}</div>
          </div>
          

        </div>
      </div>
    </div>
  </template>
  
  <script>
  import { useStore } from 'vuex';
  import $ from 'jquery';
  
  export default {
    name: "AnswerSheet",
    setup() {
      const store = useStore();
  
      const get_ans = (questionId, give_ans, numId) => {
        store.commit("updateAns", { questionId, give_ans });
        store.commit("update_degreeBox", numId);
      };
  
      const isSelected = (questionId, option) => {
        const questionAns = store.state.questionAns.find((ans) => ans.id === questionId);
        return questionAns && questionAns.answerKey === option;
      };

      $.ajax({
        url:store.state.backendIp+'/paper/list',
        type:'get',
        success(resp){
            store.commit("get_AdminSheetList",resp.data);
        },
        error(){
            console.log("接收失败！");
        }
     });

     const update_paperId = id =>{
      store.commit("update_paperId",id);
      //console.log(store.state.paperId);
     }
  
      return {
        get_ans,
        isSelected,
        update_paperId
      };
    },
  };
  </script>
  
  <style scoped>
  .sheet-detail{
    cursor: pointer;
  }
  .sheet-detail-info{
    white-space: nowrap;
  }

  .border-base{
    margin:5px 6px 5px 6px;
    border: 1.5px solid black;
    padding: 7px 7px 7px 7px;
    border-radius: 12px;
  }
  .content-field {
    flex: 4;
    margin-left: 10px;
    width: 100%;
  }
  
  .option {
    height: 30px;
    cursor: pointer;
    transition: transform 0.5s ease;
    margin-bottom: 10px;
  }
  
  .option:hover {
    transform: translate(-2px, -2px);
  }
  
  .selected-option {
    color: red;
  }
  
  .question-content {
    margin-bottom: 10px;
  }
  
  .question {
    margin-bottom: 7px;
    font-size: 17px;
  }

  .sheet-field{
    display: flex;
    flex-direction: row;
    justify-content: left;
    overflow-x: scroll;
    width: 526px;
  }
  </style>
  