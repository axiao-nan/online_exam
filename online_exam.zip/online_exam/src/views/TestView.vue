<template>
  <AdminAddSheet />
</template>

<script>
import AdminAddSheet from '@/components/AdminComponents/Modal/AdminAddSheet.vue';
export default {
  name: 'TestView',
  components: {
    AdminAddSheet
  },
}
</script>

<style scoped>
</style>
