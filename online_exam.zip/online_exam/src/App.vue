<template>
  <router-view/>
</template>

<script>
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap";
export default{
  name:"App",
  components:{
  },
}
</script>

<style scoped>

</style>
